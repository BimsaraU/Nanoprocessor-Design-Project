// Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2018.2 (win64) Build 2258646 Thu Jun 14 20:03:12 MDT 2018
// Date        : Sat May 17 15:08:51 2025
// Host        : Bimsara running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode synth_stub {c:/Users/ASUS
//               TUF/Documents/Vivado/Nano_Alts/Exp2/Exp.srcs/sources_1/ip/c_counter_binary_1/c_counter_binary_1_stub.v}
// Design      : c_counter_binary_1
// Purpose     : Stub declaration of top-level module interface
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// The synthesis directives are for Synopsys Synplify support to prevent IO buffer insertion.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
(* x_core_info = "c_counter_binary_v12_0_12,Vivado 2018.2" *)
module c_counter_binary_1(CLK, SCLR, LOAD, L, Q)
/* synthesis syn_black_box black_box_pad_pin="CLK,SCLR,LOAD,L[2:0],Q[2:0]" */;
  input CLK;
  input SCLR;
  input LOAD;
  input [2:0]L;
  output [2:0]Q;
endmodule
